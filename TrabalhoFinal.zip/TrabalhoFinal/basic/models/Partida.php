<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "partida".
 *
 * @property integer $id_partida
 * @property integer $id_user_1
 * @property integer $id_user_2
 * @property integer $vencedor
 *
 * @property Jogada[] $jogadas
 * @property Usuario $idUser1
 * @property Usuario $idUser2
 */
class Partida extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'partida';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_user_1', 'id_user_2', 'vencedor'], 'integer'],
            [['id_user_1'], 'exist', 'skipOnError' => true, 'targetClass' => Usuario::className(), 'targetAttribute' => ['id_user_1' => 'id_user']],
            [['id_user_2'], 'exist', 'skipOnError' => true, 'targetClass' => Usuario::className(), 'targetAttribute' => ['id_user_2' => 'id_user']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_partida' => 'Id Partida',
            'id_user_1' => 'Jogador1',
            'id_user_2' => 'Jogador2',
            'vencedor' => 'Vencedor',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getJogadas()
    {
        return $this->hasMany(Jogada::className(), ['id_partida' => 'id_partida']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdUser1()
    {
        return $this->hasOne(Usuario::className(), ['id_user' => 'id_user_1']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdUser2()
    {
        return $this->hasOne(Usuario::className(), ['id_user' => 'id_user_2']);
    }
}
