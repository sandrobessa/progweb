<?php

namespace app\models;

use Yii;
use yii\behaviors\AttributeBehavior;
use yii\db\ActiveRecord;

/**
 * This is the model class for table "usuario".
 *
 * @property integer $id_user
 * @property integer $id_curso
 * @property string $nome
 * @property string $email
 * @property integer $pontuacao
 *
 * @property Jogada[] $jogadas
 * @property Partida[] $partidas
 * @property Partida[] $partidas0
 * @property Curso $idCurso
 */
class Usuario extends \yii\db\ActiveRecord
{
    
    /*public function beforeSave($insert)
    {
        if (parent::beforeSave($insert)) {
            if ($insert) {
                
                $this->pontuacao = 0;
             }
            
            return true;
        } 
        else 
        {
            return false;
        }      
    }*/

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCurso()
    {
        return $this->hasOne(Curso::className(), ['id_curso' => 'id_curso']);
    }

    public function behaviors()
    {
        return [
            [
                'class' => AttributeBehavior::className(),
                'attributes' => [
                    ActiveRecord::EVENT_BEFORE_INSERT => ['pontuacao'],
                    ActiveRecord::EVENT_BEFORE_UPDATE => ['pontuacao'],
                ],
                'value' =>function ($event){
                  return '0';
                }
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'usuario';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_curso', 'nome', 'email'], 'required'],
            [['id_curso', 'pontuacao'], 'integer'],
            [['nome'], 'string', 'max' => 50],
            [['email'], 'string', 'max' => 50],
            [['id_curso'], 'exist', 'skipOnError' => true, 'targetClass' => Curso::className(), 'targetAttribute' => ['id_curso' => 'id_curso']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_user' => 'Id User',
            'id_curso' => 'Curso de Graduação',
            'nome' => 'Nome',
            'email' => 'Endereço de Email',
            'pontuacao' => 'Pontuacao',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getJogadas()
    {
        return $this->hasMany(Jogada::className(), ['id_user' => 'id_user']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPartidas()
    {
        return $this->hasMany(Partida::className(), ['id_user_1' => 'id_user']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPartidas0()
    {
        return $this->hasMany(Partida::className(), ['id_user_2' => 'id_user']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdCurso()
    {
        return $this->hasOne(Curso::className(), ['id_curso' => 'id_curso']);
    }
}
